angular.module('pb.widgets')
  .directive('pbLink', function() {
    return {
      template: '<div class="text-{{ properties.alignment }}">\n    <a ng-class="properties.buttonStyle !== \'none\' ? \'btn btn-\' + properties.buttonStyle : \'\'" ng-href="{{properties.targetUrl}}">{{properties.text}}</a>\n</div>\n'
    };
  });
